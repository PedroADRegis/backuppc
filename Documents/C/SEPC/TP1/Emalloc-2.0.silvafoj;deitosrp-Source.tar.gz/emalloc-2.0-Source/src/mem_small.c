/******************************************************
 * Copyright Grégory Mounié 2018                      *
 * This code is distributed under the GLPv3+ licence. *
 * Ce code est distribué sous la licence GPLv3+.      *
 ******************************************************/

#include <assert.h>
#include <stdint.h>
#include "mem.h"
#include "mem_internals.h"

static inline void build_chunkpool_linked_list(unsigned long);
static inline void * chunkpool_head(void);
static inline void advance_chunkpool_head(void);

void *
emalloc_small(unsigned long size)
{
    if (arena.chunkpool == NULL) {
        unsigned long const bytes_allocated = mem_realloc_small();
        build_chunkpool_linked_list(bytes_allocated);
    }

    void * address_of_available_zone = chunkpool_head();
    advance_chunkpool_head();

    return mark_memarea_and_get_user_ptr(address_of_available_zone, CHUNKSIZE, SMALL_KIND);
}

static inline void build_chunkpool_linked_list(unsigned long bytes_allocated) {
    unsigned long const blocks = bytes_allocated / CHUNKSIZE;
    unsigned long * next_block_address = (unsigned long *) arena.chunkpool;

    for (int i = 0; i != (blocks - 1); i++) {
        *next_block_address = (unsigned long)((unsigned long *)arena.chunkpool + (CHUNKSIZE / sizeof(unsigned long)) * (i + 1));
        next_block_address = (unsigned long *)((uint8_t *) next_block_address + CHUNKSIZE);
    }

    *next_block_address = (unsigned long)NULL;
}

static inline void * chunkpool_head(void) {
    return arena.chunkpool;
}

static inline void advance_chunkpool_head(void) {
    arena.chunkpool = (void *) *((unsigned long *) chunkpool_head());
}

void efree_small(Alloc a) {
    unsigned long * base = (unsigned long *) a.ptr;
    *base = (unsigned long) chunkpool_head();
    arena.chunkpool = a.ptr;
}
