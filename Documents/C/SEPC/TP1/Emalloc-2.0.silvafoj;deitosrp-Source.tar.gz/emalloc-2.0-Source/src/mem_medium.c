/******************************************************
 * Copyright Grégory Mounié 2018                      *
 * This code is distributed under the GLPv3+ licence. *
 * Ce code est distribué sous la licence GPLv3+.      *
 ******************************************************/

#include <stdint.h>
#include <assert.h>
#include <stdbool.h>

#include "mem.h"
#include "mem_internals.h"

void * remove_first_element_from_index(unsigned long index);
void build_linked_list(unsigned long index, void *first_element);
void merge_buddies(void * address, unsigned int index);
bool is_buddy_in_the_list(void *list, void *address);
void remove_buddy(void *buddy_address, int index);

unsigned int puiss2(unsigned long size) {
    unsigned int p=0;
    size = size -1; // allocation start in 0
    while(size) {  // get the largest bit
	p++;
	size >>= 1;
    }
    if (size > (1 << p))
	p++;
    return p;
}

unsigned int twos_power(int index) {
    return (index > 0) ? 2 << (index - 1) : 1;
}

void *
emalloc_medium(unsigned long size)
{
    assert(size < LARGEALLOC);
    assert(size > SMALLALLOC);

    size += 32;
    unsigned int index = puiss2(size);

    while (arena.TZL[index] == 0) {
        if (index == (FIRST_ALLOC_MEDIUM_EXPOSANT + arena.medium_next_exponant)) {
            mem_realloc_medium();
            *((unsigned long *)arena.TZL[index]) = (unsigned long) NULL;
        } else {
            index += 1;
        }
    }

    unsigned long size_of_region = twos_power(index);
    while ((size_of_region / 2) > size) {
        void *first_element = remove_first_element_from_index(index);

        index -= 1;

        build_linked_list(index, first_element);

        size_of_region = twos_power(index);
    }

    void * address_of_available_zone = arena.TZL[index];

    arena.TZL[index] = (void *) (*(unsigned long *)arena.TZL[index]);

    return mark_memarea_and_get_user_ptr(address_of_available_zone, size, MEDIUM_KIND);
}

void * remove_first_element_from_index(unsigned long index) {
    void * first_element_address = arena.TZL[index];

    unsigned long * second_element_address = (unsigned long *) (*(unsigned long *)arena.TZL[index]);
    arena.TZL[index] = (void *) second_element_address;

    return first_element_address;
}

void build_linked_list(unsigned long index, void *first_element) {
    unsigned long block_size = twos_power(index);

    unsigned long *next_element = (unsigned long *) first_element;
    *next_element = (unsigned long) (first_element + block_size);

    unsigned long * second_element = (unsigned long *) *next_element;
    *second_element = (unsigned long) NULL;

    arena.TZL[index] = first_element;
}

void efree_medium(Alloc a) {
    merge_buddies(a.ptr, puiss2(a.size));
}

void merge_buddies(void * freed_block, unsigned int index) {
    void * buddy_address = (void *) ((long unsigned int) freed_block ^ (twos_power(index)));

    if (is_buddy_in_the_list(arena.TZL[index], buddy_address))
    {
        remove_buddy(buddy_address, index);

        void *smallest = (buddy_address < freed_block) ? buddy_address : freed_block;
        merge_buddies(smallest, index + 1);

    } else {
        *(unsigned long *)freed_block = (unsigned long) arena.TZL[index];
        arena.TZL[index] = freed_block;
    }
}

void remove_buddy(void *buddy_address, int index) {
    void *head = arena.TZL[index];
    void *last_head = head;

    if (arena.TZL[index] == buddy_address) {
        arena.TZL[index] = (void *) *(unsigned long *)buddy_address;
    } else {
        while (head != buddy_address) {
            last_head = head;
            head = (void *) *(unsigned long *)head;
        }

        *(unsigned long *)last_head = *(unsigned long *)head;
    }
}

bool is_buddy_in_the_list(void *list, void *buddy_address) {
    if (list == NULL || buddy_address == NULL) {
        return false;
    }

    void *next = list;
    while (next != NULL) {
        if (next == buddy_address) {
            return true;
        }
        next = (void *) *((unsigned long *)next);
    }

    return false;
}
