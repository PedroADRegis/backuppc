/******************************************************
 * Copyright Grégory Mounié 2018                      *
 * This code is distributed under the GLPv3+ licence. *
 * Ce code est distribué sous la licence GPLv3+.      *
 ******************************************************/

#include <sys/mman.h>
#include <assert.h>
#include <stdint.h>
#include "mem.h"
#include "mem_internals.h"

static inline void assign_uint64_to_pointer(void *ptr, unsigned long value);

unsigned long knuth_mmix_one_round(unsigned long in)
{
    return in * 6364136223846793005UL % 1442695040888963407UL;
}

void *mark_memarea_and_get_user_ptr(void *ptr, unsigned long size, MemKind k)
{
    // taille | magic | mémoire demandée par l'utilisateur | inutilisé           | magic | taille
    //   8B      8B                                                                  8B      8B

    uint8_t *ptr_u8 = (uint8_t *) ptr;
    uint64_t magic = knuth_mmix_one_round((uint64_t) ptr);
    magic = (magic & (~0b11UL)) | (uint64_t) k;

    assign_uint64_to_pointer(&ptr_u8[0], size);
    assign_uint64_to_pointer(&ptr_u8[8], magic);
    assign_uint64_to_pointer(&ptr_u8[size - 16], magic);
    assign_uint64_to_pointer(&ptr_u8[size - 8], size);

    return (void *) &ptr_u8[16];
}

static inline void assign_uint64_to_pointer(void *ptr, uint64_t value) {
    uint64_t *ulong_ptr = (uint64_t *) ptr;
    *ulong_ptr = value;
}

Alloc
mark_check_and_get_alloc(void *ptr)
{
    // taille | magic | mémoire demandée par l'utilisateur | inutilisé           | magic | taille
    //   8B      8B   ^ ptr                                                          8B      8B
    uint8_t *ptr_u8 = (uint8_t *)ptr;

    uint64_t const size_1 =  *((uint64_t *) &ptr_u8[-16]);
    uint64_t const magic_1 = *((uint64_t *) &ptr_u8[-8]);

    uint64_t const magic_2 = *((uint64_t *) &ptr_u8[size_1 - 32]);
    uint64_t const size_2 = *((uint64_t *) &ptr_u8[size_1 - 24]);

    assert(magic_1 == magic_2);
    assert(size_1 == size_2);

    MemKind kind = (MemKind) (magic_1 & 0x3UL);

    Alloc a = {.ptr = ptr_u8 - 16, .kind = kind, .size = size_1};

    return a;
}


unsigned long
mem_realloc_small() {
    assert(arena.chunkpool == 0);
    unsigned long size = (FIRST_ALLOC_SMALL << arena.small_next_exponant);
    arena.chunkpool = mmap(0,
			   size,
			   PROT_READ | PROT_WRITE | PROT_EXEC,
			   MAP_PRIVATE | MAP_ANONYMOUS,
			   -1,
			   0);
    if (arena.chunkpool == MAP_FAILED)
	handle_fatalError("small realloc");
    arena.small_next_exponant++;
    return size;
}

unsigned long
mem_realloc_medium() {
    uint32_t indice = FIRST_ALLOC_MEDIUM_EXPOSANT + arena.medium_next_exponant;
    assert(arena.TZL[indice] == 0);
    unsigned long size = (FIRST_ALLOC_MEDIUM << arena.medium_next_exponant);
    assert( size == (1 << indice));
    arena.TZL[indice] = mmap(0,
			     size*2, // twice the size to allign
			     PROT_READ | PROT_WRITE | PROT_EXEC,
			     MAP_PRIVATE | MAP_ANONYMOUS,
			     -1,
			     0);
    if (arena.TZL[indice] == MAP_FAILED)
	handle_fatalError("medium realloc");
    // align allocation to a multiple of the size
    // for buddy algo
    arena.TZL[indice] += (size - (((intptr_t)arena.TZL[indice]) % size));
    arena.medium_next_exponant++;
    return size; // lie on allocation size, but never free
}


// used for test in buddy algo
unsigned int
nb_TZL_entries() {
    int nb = 0;

    for(int i=0; i < TZL_SIZE; i++)
	if ( arena.TZL[i] )
	    nb ++;

    return nb;
}
